 // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyB2TU4V3sH_Gq6myQ7Z9-By-4GwHNxjBnE",
    authDomain: "soccerxls-49f7e.firebaseapp.com",
    databaseURL: "https://soccerxls-49f7e.firebaseio.com",
    projectId: "soccerxls-49f7e",
    storageBucket: "",
    messagingSenderId: "511858848533",
    appId: "1:511858848533:web:b2816dde0d3af119"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);